<?php
/*
Plugin Name: Simple Job Circular
Plugin URI: http://techhaat.com/plugins/simplejobcircular
Author: Tech Haat
Author URI: https://shakilzaman.com
Description: Simple way to manage company jobs and applicants.   
Version: 1.0
License: GPLv2 or later
Text Domain: simplejobcircular
*/
if (!defined('ABSPATH')) exit;
// Include Files
require_once dirname(__FILE__).'/lib/cmb2/init.php';
require_once dirname(__FILE__).'/lib/cmb2/functions.php';
require_once dirname(__FILE__).'/includes/submenupages.php';
require_once dirname(__FILE__).'/includes/database.php';
require_once dirname(__FILE__).'/includes/shortcodes.php';

// Enqueue Files
function sjc_enque_style(){       
    wp_enqueue_style( 'bootstrap_min_css', plugins_url('assets/css/modalstyle.css',__FILE__ ));
	wp_enqueue_script( 'bootstrap_min', plugins_url('assets/js/bootstrap.min.js',__FILE__ ),array('jquery'),'',true);
}
add_action('wp_enqueue_scripts','sjc_enque_style');

// Register Jobs post type 
function sjc_create_post() {
  register_post_type( 'jobcircular',
    array(
      'labels' => array(
        'name' => __( 'Job Circular' ),
        'singular_name' => __( 'Job Circular' ),
        'add_new_item' => __( 'Add New Job' ),
        'add_new' => __( 'Add New Job' )
      ),
      'public' => true,
      'has_archive' => true,
    )
  );
}

add_action( 'init', 'sjc_create_post' );

// Admin Menu
function sjc_menu()
{
	add_submenu_page( 'edit.php?post_type=jobcircular', 'Applicants', 'Applicants', 'manage_options', 'applicants', 'sjc_applicants_page');
}

add_action('admin_menu', 'sjc_menu');

// Remove applicant table
function sjc_remove_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'NestoNovo';
    $sql = "DROP TABLE IF EXISTS applicant";
    $wpdb->query($sql);
    delete_option("my_plugin_db_version");
}
register_deactivation_hook( __FILE__, 'sjc_remove_table' );
?>