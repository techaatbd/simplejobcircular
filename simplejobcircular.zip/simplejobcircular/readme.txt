Simple Job Circular
.......................

Simple Job Circular is a wordpress plugin for 
make a easy Job Management system in your wordpress website.

User Manual
............

1. Upload and activate Simple Job Circular
2. Use shortcode [job_circular] to any new page
3. Add new Jobs
4. View jobs on the page
5. Click on View details.
6. Visitor can Apply for jobs with their details 
7. Check Application on the admin menu. 

Thanks For You
 