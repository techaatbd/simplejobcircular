<?php
if (!defined('ABSPATH')) exit;
// CREATE TABLE START
global $wpdb;
$table_name = "applicant";

if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name){
$sql = "CREATE TABLE applicant(
	applicant_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,

	job_id VARCHAR(200) NOT NULL,
	
	name VARCHAR(200) NOT NULL,

	email VARCHAR(200) NOT NULL,
	
	phone VARCHAR(200) NOT NULL,	

	about LONGTEXT NULL 
)";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta($sql);
}
?>