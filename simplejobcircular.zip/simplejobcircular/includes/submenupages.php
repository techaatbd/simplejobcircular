<?php
if (!defined('ABSPATH')) exit;
function sjc_metabox($metabox){
	$metabox[] = array(
	
		'id'=> 'company_details',
		'title'=> 'Company Details',
		'object_types' => array('jobcircular'),
		'fields' => array(
		    array(
			  'name' => 'Company Name',
			  'type' => 'text',
			  'id' => 'company-name',
			  'desc' => 'Name of the Company'
			),
			
			array(
			  'name' => 'Company Address',
			  'type' => 'textarea_small',
			  'id' => 'company-address',
			  'desc' => 'Company location'
			),
			
			array(
			  'name' => 'Company Email',
			  'type' => 'text',
			  'id' => 'company-email',
			  'desc' => 'Company Email'
			),
		),
		
	);		
	return $metabox;
}

add_filter('cmb2_meta_boxes','sjc_metabox');

function sjc_metabox2($metabox){
	$metabox[] = array(	
		'id'=> 'job_details',
		'title'=> 'Job Details',
		'object_types' => array('jobcircular'),
		'fields' => array(			
			array(
			  'name'             => 'Job Category',
				'desc'             => 'Select the type of the job',
				'id'               => 'job_category',
				'type'             => 'select',
				'show_option_none' => true,
				'default'          => 'custom',
				'options'          => array(
					'Accounting/Finance' => __( 'Accounting/Finance', 'jobcircular' ),
					'Bank/ Non-Bank Fin. Institution' => __( 'Bank/ Non-Bank Fin. Institution', 'jobcircular' ),
					'Commercial/Supply Chain' => __( 'Commercial/Supply Chain', 'jobcircular' ),
					'Education/Training' => __( 'Education/Training', 'jobcircular' ),
					'Engineer/Architects' => __( 'Engineer/Architects', 'jobcircular' ),
					'Garments/Textile' => __( 'Garments/Textile', 'jobcircular' ),
					'HR/Org. Development' => __( 'HR/Org. Development', 'jobcircular' ),
					'Gen Mgt/Admin' => __( 'Gen Mgt/Admin', 'jobcircular' ),
					'Design/Creative' => __( 'Design/Creative', 'jobcircular' ),
					'Production/Operation' => __( 'Production/Operation', 'jobcircular' ),
					'Hospitality/ Travel/ Tourism' => __( 'Hospitality/ Travel/ Tourism', 'jobcircular' ),
					'Beauty Care/ Health & Fitness' => __( 'Beauty Care/ Health & Fitness', 'jobcircular' ),
					'Electrician/ Construction/ Repair' => __( 'Electrician/ Construction/ Repair', 'jobcircular' ),
					'IT & Telecommunication' => __( 'IT & Telecommunication', 'jobcircular' ),
					'Marketing/Sales' => __( 'Marketing/Sales', 'jobcircular' ),
					'Customer Support/Call Centre' => __( 'Customer Support/Call Centre', 'jobcircular' ),
					'Media/Ad./Event Mgt' => __( 'Media/Ad./Event Mgt', 'jobcircular' ),
					'Medical/Pharma' => __( 'Medical/Pharma', 'jobcircular' ),
					'Agro (Plant/Animal/Fisheries)' => __( 'Agro (Plant/Animal/Fisheries)', 'jobcircular' ),
					'NGO/Development' => __( 'NGO/Development', 'jobcircular' ),
					'NGO/Development' => __( 'Research/Consultancy', 'jobcircular' ),
					'Secretary/Receptionist' => __( 'Secretary/Receptionist', 'jobcircular' ),
					'Data Entry/Operator/BPO' => __( 'Data Entry/Operator/BPO', 'jobcircular' ),
					'Driving/Motor Technician' => __( 'Driving/Motor Technician', 'jobcircular' ),
					'Security/Support Service' => __( 'Security/Support Service', 'jobcircular' ),
					'Law/Legal' => __( 'Law/Legal', 'jobcircular' ),
					'Others' => __( 'Others', 'jobcircular' ),
				),
			),
			
			array(
			  'name' => 'Job Location',
			  'type' => 'textarea_small',
			  'id' => 'job-location',
			  'desc' => 'Job location where applicants have to work'
			),
			
			array(
			  'name' => 'Vacancy',
			  'type' => 'text',
			  'id' => 'vacancy',
			  'desc' => 'How many employee needed '
			),
			
			array(
			  'name' => 'Salary',
			  'type' => 'text',
			  'id' => 'salary',
			  'desc' => 'Expected salary range '
			),
			
			array(
			  'name' => 'Deadline',
			  'type' => 'text_date',
			  'id' => 'deadline',
			  'desc' => 'Last date of submission '
			),
		),
		
	);
	return $metabox;
}

add_filter('cmb2_meta_boxes','sjc_metabox2');

//Applicants Page
function sjc_applicants_page(){
?>

<div class="wrap">
<h1 class="wp-heading-inline">Applicants</h1>
</div>

<?php
global $wpdb; 
// Delete To Do
if(isset($_GET['aid'])){
  
  $id = $_GET['aid']; 
  $deleteTodo = $wpdb->delete( 'applicant', array( 'applicant_id' => $id ) );
  if($deleteTodo){
	  echo "Applicant Deleted Successfully";
  }
}
?>
<table class="table widefat fixed" style="margin-top:20px">
    <thead>
      <tr>
        <th><b>Job Title</b></th>
        <th><b>Name</b></th>
        <th><b>Email</b></th>
        <th><b>Phone</b></th>
        <th><b>Delete</b></th>
      </tr>
    </thead>
    <tbody>
	
<?php
$applicants = $wpdb->get_results('SELECT * FROM applicant ORDER BY applicant_id DESC');
foreach($applicants as $applicant){
?>		
	
    <tr>
        <td><?php echo get_the_title($applicant->job_id); ?></td>
        <td><?php echo $applicant->name; ?></td>
        <td><?php echo $applicant->email; ?> </td>
        <td><?php echo $applicant->phone; ?></td>
		
        <td>
		<?php $nonce = wp_create_nonce( $applicant->name ); ?>
		<a href="<?php echo site_url();?>/wp-admin/admin.php?page=applicants&aid=<?php echo $applicant->applicant_id; ?>&_wpnonce=<?php echo esc_attr( $nonce );?>">Delete</a>
		</td>
    </tr>

<?php 
}
?>	  
    </tbody>
</table>
		
<?php 		
}
?>

<?php
// create custom plugin settings menu
add_action('admin_menu', 'sjc_settings_menu',99999);

function sjc_settings_menu() {
	add_submenu_page('edit.php?post_type=jobcircular','Job Settings', 'Settings', 'administrator', __FILE__, 'sjc_settings_page' , plugins_url('/images/icon.png', __FILE__));
}

function register_sjc_settings() {
	//register our settings
	register_setting( 'sjc-settings-group', 'new_option_name' );
	register_setting( 'sjc-settings-group', 'some_other_option' );
}
add_action( 'admin_init', 'register_sjc_settings' );

function sjc_settings_page() {
?>
<div class="wrap">
<h1>Job Settings</h1>

<form method="post" action="options.php">
<?php settings_fields( 'sjc-settings-group' ); ?>
<?php do_settings_sections( 'sjc-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Currency</th>
        <td><input type="text" name="new_option_name" value="<?php echo esc_attr( get_option('new_option_name') ); ?>" /></td>
        </tr>
    </table>
    
<?php submit_button();?>

</form>
</div>
<?php } ?>

<?php
// Manage Custom Columns 
add_filter( 'manage_edit-jobcircular_columns', 'edit_sjc_columns' ) ;

function edit_sjc_columns( $columns ) {

	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => __( '<b>Jobs</b>' ),
		'job_category' => __( '<b>Category</b>' ),
		'company' => __( '<b>Company</b>' ),
		'salary' => __( '<b>Salary</b>' ),
		'vacancy' => __( '<b>Vacancy</b>' ),
		'deadline' => __( '<b>Deadline</b>' ),
		'job-location' => __( '<b>Location</b>' )
	);

	return $columns;
}

function sjc_custom_columns( $columns, $post_id ) {
	global $post;
	
	switch( $columns ) {
		
		case 'job_category' :
			$category =  get_post_meta( $post_id, 'job_category', true );
			echo $category;
			break;

		case 'company' :
			$company =  get_post_meta( $post_id, 'company-name', true );
			echo $company;
			break;
		
		case 'salary' :
			$salary =  get_option('new_option_name').get_post_meta( $post_id, 'salary', true );
			echo $salary;
			break;
		
		case 'vacancy' :
			$vacancy =  get_post_meta( $post_id, 'vacancy', true );
			echo $vacancy;
			break;
		
		case 'deadline' :
			$deadline =  get_post_meta( $post_id, 'deadline', true );
			echo $deadline;
			break;
		
		case 'job-location' :
			$joblocation =  get_post_meta( $post_id, 'job-location', true );
			echo $joblocation;
			break;
			
			break;
	}
}

add_action( 'manage_jobcircular_posts_custom_column', 'sjc_custom_columns', 10, 2 );
?>